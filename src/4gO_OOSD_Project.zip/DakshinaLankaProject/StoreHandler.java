package DakshinaLankaProject;

import java.util.*;

public class StoreHandler
{
	private Stock stock;
	private ArrayList<ItemCategory> itemCategoryList;

	public final void removeFromStore(int itemID)
	{
		
	}

	public final void addToCategoryList(int item_id, Supplier supplier, String manufacturer, float buying_price, float selling_price, float amount)
	{
		
	}

	public final void addToStock(Supplier supplier, ArrayList<ItemCategory> itemCategoryList)
	{
		
	}

	public final void updateStock(Stock stock)
	{
		
	}

	public final boolean isItemLow(int itemID)
	{
		
	}

	public final void getStockDetails()
	{
		
	}

	public final void transferToShowroom(int itemID, int ShowroomID)
	{
		
	}

	public final void TransferToStore(int itemID)
	{
		
	}
}