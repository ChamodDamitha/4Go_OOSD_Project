package DakshinaLankaProject;

import java.util.ArrayList;

public class RejectedStock extends Stock
{

    public RejectedStock(Supplier supplier, ArrayList<ItemCategory> itemCategories) {
        super(supplier, itemCategories);
    }
}