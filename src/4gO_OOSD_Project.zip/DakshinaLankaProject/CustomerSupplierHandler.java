package DakshinaLankaProject;

public class CustomerSupplierHandler
{
	private CustomerSupplierDB customerSupplierDB;

	public final void addCustomer(String name, String address, String telephone)
	{
		
	}

	public final void addSupplier(String name, String address, String telephone)
	{

	}
}