package DakshinaLankaProject;

public class Item extends ItemCategory
{
	private final int amount = 1;

    public Item(float buying_price, String item_id, float selling_price, Supplier supplier, String manufacturer, int amount) {
        super(buying_price, item_id, selling_price, supplier, manufacturer, amount);
    }
}