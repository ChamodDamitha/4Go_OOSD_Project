package DakshinaLankaProject;

public class OrderDB
{
	public final int getNextIndex()
	{
		
	}

	public final void storeNewOrder(Order order)
	{
		
	}

	public final void stroeRepairOrder(RepairOrder repairOrder)
	{
		
	}
}