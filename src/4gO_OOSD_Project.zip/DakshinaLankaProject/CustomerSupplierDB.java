package DakshinaLankaProject;

public class CustomerSupplierDB
{
	public final int getNextCustomerIndex()
	{
		
	}

	public final void storeCustomer(Customer customer)
	{
		
	}

	public final int getNextSupplierIndex()
	{
		
	}

	public final void storeSupplier(Supplier supplier)
	{
		
	}
}