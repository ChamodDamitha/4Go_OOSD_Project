package DakshinaLankaProject;

import java.util.ArrayList;

public class RepairOrder extends Order
{
	private String description;

    public RepairOrder(Customer customer, int order_id, ArrayList<Item> items, String date) {
        super(customer, order_id, items, date);
    }
}