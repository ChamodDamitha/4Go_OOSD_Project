package DakshinaLankaProject;

import java.util.*;

public class StoreDB
{
	public final ArrayList<Item> checkAvailability(String item_id)
	{
		
	}

	public final void removeStock(Stock stock)
	{
		
	}

	public final void addToReturenStock(Stock stock)
	{
		
	}

	public final void addToStock(Stock stock)
	{
		
	}

	public final int getNextStoreIndex()
	{
		
	}

	public final void addToLowItems(int itemID)
	{
		
	}

	public final void transferToShowroom(int itemID, int showroomID)
	{
		
	}

	public final int getNextShowroomIndex()
	{
		
	}

	public final void trnsferToStore(int ShowroomID)
	{
		
	}
}