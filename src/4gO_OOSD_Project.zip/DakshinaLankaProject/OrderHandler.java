package DakshinaLankaProject;

import java.util.*;

public class OrderHandler
{
	private OrderDB orderDB;
	private ArrayList<Item> items;
	private Order order;
	private CustomerSupplierDB customerSupplierDB;

	public final void addOrder(String customerID, String frameShowroomID, String lenseCodeL, String lenseCodeR)
	{
		
	}

	public final ArrayList<Item> checkAvailability(String showroom_id)
	{
		
	}

	public final boolean IsOrderFinished(String order_id)
	{
		
	}

	public final boolean IsOrderExpired(String order_id)
	{
		
	}

	public final void addRepairOrder(String customerID, String description)
	{
		

	}

	public final void completeOrder(int orderID)
	{
		

	}

	public final void updateOrder(Order order)
	{
		

	}
}