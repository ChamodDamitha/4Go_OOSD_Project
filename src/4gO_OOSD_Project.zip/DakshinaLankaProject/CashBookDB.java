package DakshinaLankaProject;

import java.util.*;

public class CashBookDB
{
	private ArrayList<Payment> payments;

	public final void addPayment(Payment payment)
	{
		
	}
}