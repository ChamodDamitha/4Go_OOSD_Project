package DakshinaLankaProject;

import java.util.*;

public class Stock
{
	private Supplier suplier;
	private ArrayList<ItemCategory> itemCategories;
	private ArrayList<Payment> payments;
	private float totalValue;
	private String date;

	public Stock(Supplier supplier, ArrayList<ItemCategory> itemCategories)
	{
		
	}

	public final void addPayment(float amount)
	{
		
	}
}