package DakshinaLankaProject;

public class PaymentHandler
{
	private Order order;
	private CashBookDB cashbookDB;

	public final void getCustomerPaymentStatus(int orderID)
	{
		

	}

	public final void setCustomerPayment(float amount, int orderID)
	{
		
	}

	public final void setSupplierPayment(float amount, int stockID)
	{
		
	}

	public final void getSupplierPaymentStatus(int stockID)
	{
		
	}

	public final void getTransactionReport()
	{
		
	}
}